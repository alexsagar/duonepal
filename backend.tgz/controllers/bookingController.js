const cloudinary = require('../utils/cloudinary');
const sendBookingEmail = require('../utils/email');
const sendTelegramNotification = require('../utils/telegram');

exports.bookTest = async (req, res) => {
  try {
    const { name, email, phone, date, message, tier, price } = req.body;
    let receiptUrl = null;

    // Defensive: require receipt file
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'Receipt is required' });
    }

    // Upload file if present
    if (req.file) {
      // NOTE: Multer is configured with memoryStorage; we receive buffer
      // TODO: validate mime/size (defense in depth)
      // TODO: Alternatively, forward to Telegram sendDocument using the buffer

      // Upload buffer to Cloudinary
      const uploadFromBuffer = () => new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { folder: 'duolingo_receipts', resource_type: 'auto' },
          (error, result) => {
            if (error) return reject(error);
            return resolve(result);
          }
        );
        stream.end(req.file.buffer);
      });

      const result = await uploadFromBuffer();
      receiptUrl = result.secure_url;
    }

    // Prepare details
    const bookingDetails = `
      <b>Duolingo Booking</b>\n
      <b>Name:</b> ${name}\n
      <b>Email:</b> ${email}\n
      <b>Phone:</b> ${phone}\n
      <b>Date:</b> ${date}\n
      <b>Package:</b> ${tier || "standard"} (Nrs ${price || "-"})\n
      <b>Message:</b> ${message || "-"}\n
    `;

    // Send Telegram
    await sendTelegramNotification(bookingDetails, receiptUrl);

    // Send Email
    await sendBookingEmail({
      to: process.env.NOTIFY_EMAIL,
      subject: 'New Duolingo Test Booking',
      text: bookingDetails.replace(/<[^>]+>/g, ''), // plain text
      html: bookingDetails + (receiptUrl ? `<br><a href="${receiptUrl}">View Receipt</a>` : ''),
      attachmentUrl: receiptUrl,
    });

    res.json({ success: true, message: 'Payment Received! You will be contacted via Whatsapp shortly' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Booking failed. Try again.' });
  }
};
