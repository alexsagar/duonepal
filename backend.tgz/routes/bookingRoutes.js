const express = require('express');
const router = express.Router();
const multer = require('multer');
const sendTelegramNotification = require('../utils/telegram')
const bookingController = require('../controllers/bookingController');

// Multer memory storage with 10 MB cap and file type filter (images/PDF)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /^(image\/(png|jpeg|jpg|webp|gif)|application\/pdf)$/.test(file.mimetype);
    if (allowed) return cb(null, true);
    return cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE'));
  },
});

router.post('/send-telegram', async (req, res) => {
  try {
    const { name, email, phone, reason } = req.body;
    const message = `
<b>Incomplete Booking Attempt</b>
<b>Name:</b> ${name}
<b>Email:</b> ${email}
<b>Phone:</b> ${phone}
<b>Reason:</b> ${reason || "-"}
    `;
    await sendTelegramNotification(message, null);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false });
  }
});

// Receipt upload (multipart)
router.post('/book', upload.single('receipt'), bookingController.bookTest);


module.exports = router;
